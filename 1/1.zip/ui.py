import os

import customtkinter
from PIL import Image

from utils import (convert_to_ini, convert_to_xml, convert_to_yaml,
                   parse_ini_to_types, parse_xml_to_types, parse_yaml,
                   parse_yaml_to_types, save_content)


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
image = customtkinter.CTkImage(
    light_image=Image.open(f"{BASE_DIR}/images/explorer.png"), size=(25, 25)
)


class SideBar(customtkinter.CTkFrame):
    def __init__(self, master, title, values, main_frame):
        super().__init__(master)
        self.values = ["YAML", "XML", "ini"]
        self.variable = customtkinter.StringVar(value="")
        self.radiobuttons = []
        self.grid_columnconfigure(1, weight=1)

        self.label1 = customtkinter.CTkLabel(
            self,
            text="Расширение файла\n\nYaml",
            font=("Arial", 14),
            text_color="white",
            justify="center",
        )
        self.label1.grid(row=0, column=0, padx=5, pady=(10, 0), sticky="w")

        self.load_button = customtkinter.CTkButton(
            self,
            text="Load",
            fg_color="gray40",
            command=self.load_button_callback
        )
        self.load_button.grid(
            row=2, column=0,
            padx=5, pady=(10, 0),
            sticky="nsew"
        )

        self.save_button = customtkinter.CTkButton(
            self,
            text="Save",
            fg_color="gray40",
            command=self.save_button_callback
        )
        self.save_button.grid(
            row=3, column=0,
            padx=5, pady=(10, 0),
            sticky="nsew"
        )

        self.convert_button = customtkinter.CTkButton(
            self,
            text="Convert",
            fg_color="gray40",
            command=self.convert_button_callback,
        )
        self.convert_button.grid(
            row=4, column=0,
            padx=5, pady=(20, 0),
            sticky="nsew"
        )

        for i, value in enumerate(self.values):
            radiobutton = customtkinter.CTkRadioButton(
                self, text=value, value=value, variable=self.variable
            )
            radiobutton.grid(
                row=i + 5, column=0,
                padx=10, pady=(10, 0),
                sticky="w"
            )
            self.radiobuttons.append(radiobutton)

        self.main_frame = main_frame  # Добавляем ссылку на MainFrame

    def load_button_callback(self):
        # Открываем файл и считываем его содержимое
        file_path = self.main_frame.file_path_field.get(
            "1.0", "end-1c"
        )  # Получаем путь из file_path_field
        try:
            _, extension = os.path.splitext(file_path)
            extension = extension[
                1:
            ].lower()  # Убираем точку и приводим к нижнему регистру
            if extension == "yaml":
                data = parse_yaml(file_path)
                self.update_edit_box(data)
            elif extension == "ini":
                with open(file_path, "r") as file:
                    content = file.read()
                self.update_edit_box(content)
            elif extension == "xml":
                with open(file_path, "r") as file:
                    content = file.read()
                self.update_edit_box(content)
            else:
                print(f"Unsupported file extension: {extension}")

        except FileNotFoundError:
            print("File not found.")

    def convert_button_callback(self):
        selected_option = self.variable.get().lower()
        file_path = self.main_frame.file_path_field.get("1.0", "end-1c")

        try:
            _, extension = os.path.splitext(file_path)
            extension = extension[1:].lower()
            if extension == "yaml":
                data = parse_yaml_to_types(file_path)
            elif extension == "ini":
                data = parse_ini_to_types(file_path)
            elif extension == "xml":
                data = parse_xml_to_types(file_path)

            if selected_option == "yaml":
                converted_content = convert_to_yaml(data)
            elif selected_option == "ini":
                converted_content = convert_to_ini(data)
            elif selected_option == "xml":
                converted_content = convert_to_xml(data)
            else:
                print(f"Unsupported conversion option: {selected_option}")
                return

            self.main_frame.edit_box.delete("1.0", "end-1c")
            self.main_frame.edit_box.insert("1.0", converted_content)
        except Exception as e:
            print(f"Error during conversion: {e}")

    def save_button_callback(self):
        file_path = self.main_frame.file_path_field.get("1.0", "end-1c")
        # Срабатывает только если текущий путь файла не пуст
        if file_path:
            content_to_save = self.main_frame.edit_box.get("1.0", "end-1c")
            save_content(file_path, content_to_save)

    def update_edit_box(self, data):
        # Добавляем содержимое файла в edit_box в MainFrame
        self.main_frame.edit_box.delete("1.0", "end-1c")
        self.main_frame.edit_box.insert("1.0", data)


class MainFrame(customtkinter.CTkFrame):
    def __init__(self, master, title, values):
        super().__init__(master)
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self.file_path_field = customtkinter.CTkTextbox(
            master=self, height=28, corner_radius=6
        )
        self.file_path_field.grid(
            row=0, column=0,
            padx=(10, 10), pady=(10, 10),
            columnspan=2,
            sticky="ew"
        )
        self.file_path_field.configure(state="disabled")

        image = customtkinter.CTkImage(
            light_image=Image.open(f"{BASE_DIR}/images/explorer.png"),
            size=(25, 25)
        )
        self.explorer_button = customtkinter.CTkButton(
            self,
            text="",
            height=28,
            width=25,
            image=image,
            fg_color="gray40",
            command=self.explorer_button_callback,
        )
        self.explorer_button.grid(
            row=0, column=2,
            padx=(0, 10), pady=(10, 10),
            sticky="ew"
        )

        self.edit_box = customtkinter.CTkTextbox(
            master=self, height=700, corner_radius=6
        )
        self.edit_box.grid(
            row=1, column=0,
            padx=(10, 10), pady=(10, 10),
            columnspan=3, sticky="nsew"
        )

    def explorer_button_callback(self):
        # Open a file explorer window and get the file path
        file_path = customtkinter.filedialog.askopenfilename(
            defaultextension="py"
        )

        # If the user selected a file, save the file path to a variable
        if file_path:
            self.file_path_field.configure(state="normal")
            self.file_path_field.delete(0.0, "end")
            self.file_path_field.insert(index=0.0, text=file_path)
            self.file_path_field.configure(state="disabled")


class App(customtkinter.CTk):
    def __init__(self):
        super().__init__()

        self.title("my app")
        self.geometry("900x500")
        self.grid_columnconfigure((1, 1), weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.main_frame = MainFrame(
            self, "Options", values=["option 1", "option 2"]
        )
        self.main_frame.grid(
            row=0, column=1,
            padx=(0, 10), pady=(10, 10),
            sticky="nsew", columnspan=1
        )
        self.sidebar_frame = SideBar(
            self,
            title="Values",
            values=["value 1", "value 2", "value 3"],
            main_frame=self.main_frame,
        )
        self.sidebar_frame.grid(
            row=0, column=0,
            padx=10, pady=(10, 10),
            sticky="nsew", rowspan=1
        )

    def button_callback(self):
        print("checkbox_frame:", self.checkbox_frame.get())
        print("radiobutton_frame:", self.radiobutton_frame.get())


app = App()
app.mainloop()
